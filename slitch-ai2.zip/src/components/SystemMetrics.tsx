import React from 'react';
import { CheckCircle2, AlertCircle, Info, Hash } from 'lucide-react';
import { cn } from '../utils/cn';

interface SystemMetricsProps {
  num: number[];
  den: number[];
}

export const SystemMetrics: React.FC<SystemMetricsProps> = ({ num, den }) => {
  // Stability check: All coefficients of denominator must have same sign for stability (necessary but not sufficient for orders > 2)
  // For simplicity and user request, we'll check if all coefficients are positive (assuming lead is positive)
  const isStable = den.length > 0 && den.every(c => c >= 0);
  const order = den.length - 1;
  const dcGain = den[den.length - 1] !== 0 ? num[num.length - 1] / den[den.length - 1] : Infinity;

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Stability Square */}
      <div className={cn(
        "p-5 rounded-2xl border flex flex-col justify-between transition-colors",
        isStable ? "bg-emerald-50 border-emerald-100" : "bg-red-50 border-red-100"
      )}>
        <div className="flex justify-between items-start">
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#666666]">Stability</span>
          {isStable ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-500" />
          )}
        </div>
        <div className="mt-3 text-left">
          <p className={cn(
            "text-lg font-medium leading-none",
            isStable ? "text-emerald-700" : "text-red-700"
          )}>
            {isStable ? "STABLE" : "RISKY"}
          </p>
          <p className="text-[9px] text-[#888888] mt-2 font-mono leading-tight italic">
            Coeff sign check (Hurwitz heuristic)
          </p>
        </div>
      </div>

      {/* System Order Square */}
      <div className="p-5 rounded-2xl border border-brand-border bg-brand-sidebar flex flex-col justify-between">
        <div className="flex justify-between items-start">
          <span className="text-[10px] font-bold uppercase tracking-widest text-brand-secondary">System Order</span>
          <Hash className="w-4 h-4 text-brand-secondary" />
        </div>
        <div className="mt-3 text-left">
          <p className="text-xl font-medium leading-none text-brand-primary">Order {order}</p>
          <p className="text-[9px] text-brand-secondary mt-2 font-mono">deg(Polynomial)</p>
        </div>
      </div>

      {/* Response Details Matrix */}
      <div className="col-span-2 bg-brand-sidebar border border-brand-border rounded-2xl overflow-hidden shadow-sm">
        <div className="px-5 py-3 bg-white border-b border-brand-border flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-widest text-brand-secondary">Response Profile</span>
          <Info className="w-3 h-3 text-brand-secondary opacity-30" />
        </div>
        <div className="p-5 grid grid-cols-2 gap-y-5 gap-x-10 text-left">
          <MetricItem label="Steady State Gain" value={isFinite(dcGain) ? dcGain.toFixed(2) : "∞"} />
          <MetricItem label="Transfer Eq" value="G(s) = N(s)/D(s)" />
          <MetricItem label="Numerator Order" value={`${num.length - 1}`} />
          <MetricItem label="Denominator Order" value={`${den.length - 1}`} />
          <MetricItem label="Phase Lag" value="Comp. freq map" />
          <MetricItem label="Analysis Status" value="Active" />
        </div>
      </div>
    </div>
  );
};

function MetricItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-[9px] font-bold text-brand-secondary uppercase tracking-tight mb-1 opacity-60">{label}</span>
      <span className="font-mono text-xs text-brand-primary font-medium">{value}</span>
    </div>
  );
}
