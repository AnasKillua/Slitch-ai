import React, { useMemo } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import * as math from 'mathjs';

interface BodeDiagramProps {
  num: number[];
  den: number[];
}

export const BodeDiagram: React.FC<BodeDiagramProps> = ({ num, den }) => {
  const data = useMemo(() => {
    const points = [];
    
    // Function to evaluate polynomial at s = j*omega
    const evaluatePoly = (coeffs: number[], omega: number) => {
      let result = math.complex(0, 0);
      coeffs.forEach((c, i) => {
        const pow = coeffs.length - 1 - i;
        if (c === 0) return;
        // s^pow = (j*omega)^pow
        const sVal = math.pow(math.complex(0, omega), pow) as math.Complex;
        result = math.add(result, math.multiply(c, sVal)) as math.Complex;
      });
      return result;
    };

    for (let i = -2; i <= 3; i += 0.1) {
      const omega = Math.pow(10, i);
      const nVal = evaluatePoly(num, omega);
      const dVal = evaluatePoly(den, omega);
      
      const g_jw = math.divide(nVal, dVal) as math.Complex;
      
      const magnitude = math.abs(g_jw);
      const magnitudeDB = 20 * Math.log10(magnitude);
      
      // Phase in degrees
      let phase = (math.arg(g_jw) as number) * (180 / Math.PI);
      
      points.push({
        omega,
        magnitude: isFinite(magnitudeDB) ? parseFloat(magnitudeDB.toFixed(2)) : -100,
        phase: parseFloat(phase.toFixed(2)),
      });
    }
    return points;
  }, [num, den]);

  return (
    <div className="space-y-6 w-full">
      <div className="space-y-2 text-left">
        <h3 className="text-[10px] uppercase tracking-widest text-brand-secondary font-bold">Magnitude (dB)</h3>
        <div className="h-[180px] w-full bg-brand-bg rounded-xl border border-brand-border p-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEEEEE" vertical={false} />
              <XAxis 
                dataKey="omega" 
                scale="log" 
                domain={['auto', 'auto']} 
                type="number"
                tick={{ fontSize: 9, fill: '#888888' }}
                tickFormatter={(val) => val < 1 ? val.toFixed(2) : val.toFixed(0)}
              />
              <YAxis tick={{ fontSize: 9, fill: '#888888' }} unit="dB" />
              <Tooltip 
                contentStyle={{ fontSize: '10px', borderRadius: '8px', border: '1px solid #EEEEEE' }}
                labelFormatter={(val) => `ω: ${val.toFixed(2)} rad/s`}
              />
              <Line 
                type="monotone" 
                dataKey="magnitude" 
                stroke="#111111" 
                strokeWidth={1.5} 
                dot={false} 
                animationDuration={300}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="space-y-2 text-left">
        <h3 className="text-[10px] uppercase tracking-widest text-brand-secondary font-bold">Phase (deg)</h3>
        <div className="h-[180px] w-full bg-brand-bg rounded-xl border border-brand-border p-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEEEEE" vertical={false} />
              <XAxis 
                dataKey="omega" 
                scale="log" 
                domain={['auto', 'auto']} 
                type="number"
                tick={{ fontSize: 9, fill: '#888888' }}
                tickFormatter={(val) => val < 1 ? val.toFixed(2) : val.toFixed(0)}
              />
              <YAxis tick={{ fontSize: 9, fill: '#888888' }} unit="°" />
              <Tooltip 
                contentStyle={{ fontSize: '10px', borderRadius: '8px', border: '1px solid #EEEEEE' }}
                labelFormatter={(val) => `ω: ${val.toFixed(2)} rad/s`}
              />
              <Line 
                type="monotone" 
                dataKey="phase" 
                stroke="#888888" 
                strokeWidth={1.5} 
                dot={false} 
                animationDuration={300}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
