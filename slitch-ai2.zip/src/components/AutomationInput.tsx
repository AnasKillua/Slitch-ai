import React, { useState, useEffect } from 'react';
import { Settings2, Zap, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils/cn';

interface AutomationInputProps {
  num: number[];
  setNum: (val: number[]) => void;
  den: number[];
  setDen: (val: number[]) => void;
}

export const AutomationInput: React.FC<AutomationInputProps> = ({ num, setNum, den, setDen }) => {
  const [numStr, setNumStr] = useState(num.join(', '));
  const [denStr, setDenStr] = useState(den.join(', '));
  const [error, setError] = useState<string | null>(null);
  const [numValid, setNumValid] = useState(true);
  const [denValid, setDenValid] = useState(true);

  const isValidChar = (str: string) => /^[0-9\s,.\-]+$/.test(str) || str === "";

  const parseInput = (str: string) => {
    return str.split(/[\s,]+/).filter(v => v !== "").map(v => parseFloat(v));
  };

  useEffect(() => {
    const isNumFormatValid = isValidChar(numStr);
    const isDenFormatValid = isValidChar(denStr);
    
    setNumValid(isNumFormatValid);
    setDenValid(isDenFormatValid);

    if (!isNumFormatValid || !isDenFormatValid) {
      setError("Invalid characters detected. Use numbers, spaces or commas.");
      return;
    }

    const n = parseInput(numStr);
    const d = parseInput(denStr);
    
    if (n.some(isNaN) || d.some(isNaN)) {
      setError("Invalid number format. Check for trailing commas or dots.");
      return;
    }

    if (d.length === 0 || d.every(v => v === 0)) {
      setDenValid(false);
      setError("Denominator cannot be zero or empty.");
      return;
    }
    
    setError(null);
    setNum(n.length > 0 ? n : [0]);
    setDen(d);
  }, [numStr, denStr]);

  const formatPolynomial = (coeffs: number[]) => {
    if (coeffs.length === 0 || (coeffs.length === 1 && coeffs[0] === 0)) return "0";
    return coeffs.map((c, i) => {
      const pow = coeffs.length - 1 - i;
      if (c === 0) return null;
      const absC = Math.abs(c);
      const sign = c > 0 ? (i === 0 ? "" : " + ") : (i === 0 ? "-" : " - ");
      const coeffStr = absC === 1 && pow !== 0 ? "" : absC;
      const term = pow === 0 ? `${absC}` : pow === 1 ? `${coeffStr}s` : `${coeffStr}s${pow > 1 ? `^${pow}` : ''}`;
      return `${sign}${term}`;
    }).filter(t => t !== null).join('') || "0";
  };

  return (
    <div className="bg-brand-sidebar border border-brand-border rounded-2xl p-6 space-y-6">
      <div className="flex items-center gap-3 border-b border-brand-border pb-4">
        <div className="p-2 bg-stone-100 rounded-lg">
          <Settings2 className="w-4 h-4 text-brand-primary" />
        </div>
        <div>
          <h2 className="text-sm font-semibold tracking-tight">System Parameters</h2>
          <p className="text-[10px] text-brand-secondary uppercase tracking-widest font-medium text-left">Polynomial Coefficient Entry</p>
        </div>
      </div>

      <div className="space-y-5">
        <div className="space-y-2 text-left">
          <label className="text-[10px] font-bold text-brand-secondary uppercase tracking-wider">Numerator [sⁿ, ..., s⁰]</label>
          <input 
            type="text" 
            value={numStr}
            onChange={(e) => setNumStr(e.target.value)}
            placeholder="e.g. 1"
            className={cn(
              "w-full bg-white border rounded-xl px-4 py-3 text-sm font-mono focus:outline-none transition-all transition-shadow focus:shadow-sm",
              numValid ? "border-brand-border focus:border-brand-primary" : "border-red-500 focus:border-red-600 shadow-[0_0_0_1px_rgba(239,68,68,0.2)]"
            )}
          />
        </div>

        <div className="space-y-2 text-left">
          <label className="text-[10px] font-bold text-brand-secondary uppercase tracking-wider">Denominator [sᵐ, ..., s⁰]</label>
          <input 
            type="text" 
            value={denStr}
            onChange={(e) => setDenStr(e.target.value)}
            placeholder="e.g. 1, 2, 1"
            className={cn(
              "w-full bg-white border rounded-xl px-4 py-3 text-sm font-mono focus:outline-none transition-all transition-shadow focus:shadow-sm",
              denValid ? "border-brand-border focus:border-brand-primary" : "border-red-500 focus:border-red-600 shadow-[0_0_0_1px_rgba(239,68,68,0.2)]"
            )}
          />
        </div>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="flex items-center gap-2 text-red-500 text-[10px] font-medium"
          >
            <AlertCircle className="w-3 h-3" />
            <span>{error}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="pt-2">
        <div className="p-5 bg-brand-bg rounded-xl border border-brand-border border-dashed flex flex-col items-center">
          <p className="text-[9px] font-bold uppercase tracking-widest text-[#AAAAAA] mb-5">Current Model G(s)</p>
          <div className="flex flex-col items-center font-mono text-xs text-center max-w-full overflow-x-auto pb-1 scrollbar-hide">
            <span className="mb-1 border-b border-brand-primary pb-1 px-4">{formatPolynomial(num)}</span>
            <span>{formatPolynomial(den)}</span>
          </div>
        </div>
      </div>

      <button 
        disabled={!!error}
        className={cn(
          "w-full py-3 text-white rounded-xl text-[10px] font-semibold uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-sm",
          error ? "bg-stone-300 cursor-not-allowed" : "bg-brand-primary hover:scale-[1.02] active:scale-[0.98]"
        )}
      >
        <Zap className="w-3 h-3" />
        Synchronize Core Logic
      </button>
    </div>
  );
};
