import React, { useMemo } from 'react';
import { 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  ZAxis,
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import * as math from 'mathjs';

interface NyquistDiagramProps {
  num: number[];
  den: number[];
  showNegativeFreq?: boolean;
  showOriginLines?: boolean;
}

export const NyquistDiagram: React.FC<NyquistDiagramProps> = ({ 
  num, 
  den, 
  showNegativeFreq = true, 
  showOriginLines = true 
}) => {
  const data = useMemo(() => {
    const positivePoints = [];
    
    const evaluatePoly = (coeffs: number[], omega: number) => {
      let result = math.complex(0, 0);
      coeffs.forEach((c, i) => {
        const pow = coeffs.length - 1 - i;
        const sVal = math.pow(math.complex(0, omega), pow) as math.Complex;
        result = math.add(result, math.multiply(c, sVal)) as math.Complex;
      });
      return result;
    };

    // Sweep omega from 0 to large value
    // log scale sweep for better resolution near origin
    for (let i = -2; i <= 5; i += 0.05) {
      const omega = Math.pow(10, i);
      const nVal = evaluatePoly(num, omega);
      const dVal = evaluatePoly(den, omega);
      
      const g_jw = math.divide(nVal, dVal) as math.Complex;
      
      positivePoints.push({ 
        real: g_jw.re, 
        imag: g_jw.im, 
        omega 
      });
    }

    let finalPoints = [];
    if (showNegativeFreq) {
      // Mirror for negative frequencies to create the full loop
      const negativePoints = [...positivePoints].reverse().map(p => ({
        real: p.real,
        imag: -p.imag,
        omega: -p.omega
      }));
      finalPoints = [...negativePoints, ...positivePoints];
    } else {
      finalPoints = positivePoints;
    }

    return finalPoints.map(p => ({
      ...p,
      real: parseFloat(p.real.toFixed(4)),
      imag: parseFloat(p.imag.toFixed(4))
    }));
  }, [num, den, showNegativeFreq]);

  return (
    <div className="space-y-4 w-full text-left">
      <div className="flex justify-between items-end mb-2">
        <h3 className="text-[10px] uppercase tracking-widest text-brand-secondary font-bold">Nyquist Trajectory (Polar)</h3>
        <div className="flex items-center gap-1.5 grayscale opacity-50">
          <div className="w-1.5 h-1.5 rounded-full bg-brand-primary" />
          <span className="text-[9px] font-bold uppercase tracking-tighter">Im vs Re</span>
        </div>
      </div>
      
      <div className="h-[240px] w-full bg-brand-bg rounded-xl border border-brand-border p-2">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#EEEEEE" vertical={false} />
            <XAxis 
              type="number" 
              dataKey="real" 
              name="Real" 
              domain={['auto', 'auto']}
              fontSize={9}
              tick={{ fill: '#888888' }}
              label={{ value: 'Real', position: 'insideBottom', offset: -5, fontSize: 9, fill: '#888888' }}
              axisLine={{ stroke: '#EEEEEE' }}
            />
            <YAxis 
              type="number" 
              dataKey="imag" 
              name="Imaginary" 
              domain={['auto', 'auto']}
              fontSize={9}
              tick={{ fill: '#888888' }}
              label={{ value: 'Imag', angle: -90, position: 'insideLeft', fontSize: 9, fill: '#888888' }}
              axisLine={{ stroke: '#EEEEEE' }}
            />
            <ZAxis type="number" dataKey="omega" range={[0, 0]} />
            
            {showOriginLines && (
              <>
                <ReferenceLine x={0} stroke="#DDDDDD" strokeWidth={1} />
                <ReferenceLine y={0} stroke="#DDDDDD" strokeWidth={1} />
              </>
            )}

            <Tooltip 
              cursor={{ strokeDasharray: '3 3', stroke: '#888888' }}
              contentStyle={{ fontSize: '10px', borderRadius: '8px', border: '1px solid #EEEEEE' }}
              itemStyle={{ fontSize: '9px' }}
              formatter={(value: any, name: any) => [parseFloat(value).toFixed(3), name]}
            />
            
            <Scatter 
              key={`nyquist-${num.join('')}-${den.join('')}-${showNegativeFreq}`}
              name="G(jω)" 
              data={data} 
              fill="none"
              line={{ stroke: '#111111', strokeWidth: 1.5 }} 
              shape={() => null}
              isAnimationActive={true}
              animationDuration={800}
              animationEasing="ease-in-out"
            />
          </ScatterChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
