import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini API client
// Note: process.env.GEMINI_API_KEY is injected by Vite as defined in vite.config.ts
const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "" 
});

export const getGeminiChat = () => {
  return ai.chats.create({
    model: "gemini-3-flash-preview",
  });
};

export const generateGeminiContent = async (prompt: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });
  return response.text;
};

export default ai;
