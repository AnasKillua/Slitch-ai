import { tool } from "@langchain/core/tools";
import { z } from "zod";
import { PineconeStore } from "@langchain/pinecone";
import { OpenAIEmbeddings } from "@langchain/openai";
import { Pinecone as PineconeClient } from "@pinecone-database/pinecone";

let vectorStore: PineconeStore;

const getVectorStore = async () => {
  if (vectorStore) return vectorStore;

  const apiKey = process.env.PINECONE_API_KEY;
  const indexName = process.env.PINECONE_INDEX;

  if (!apiKey || !indexName) {
    throw new Error("Missing Pinecone credentials in environment.");
  }

  const pc = new PineconeClient({ apiKey });
  const index = pc.Index(indexName);

  const embeddings = new OpenAIEmbeddings();
  
  vectorStore = await PineconeStore.fromExistingIndex(embeddings, {
    pineconeIndex: index,
  });

  return vectorStore;
};

export const searchKnowledgeBase = tool(
  async ({ query }) => {
    console.log(`🔍 Searching knowledge base for: "${query}"`);
    try {
      const store = await getVectorStore();
      const results = await store.similaritySearch(query, 5);
      
      if (results.length === 0) {
        return "No relevant information found in the technical documentation.";
      }

      return results.map(doc => doc.pageContent).join("\n\n---\n\n");
    } catch (error) {
      console.error("Vector search error:", error);
      return "Error searching the knowledge base.";
    }
  },
  {
    name: "search_knowledge_base",
    description: "Search for technical engineering documentation and system identification data. Use this for specific queries about system properties.",
    schema: z.object({
      query: z.string().describe("The specific technical query to search for"),
    }),
  }
);
