import { ChatOpenAI } from "@langchain/openai";
import { createReactAgent } from "@langchain/langgraph/prebuilt";
import { MemorySaver } from "@langchain/langgraph";
import { searchKnowledgeBase } from "./tools.js";

const checkpointer = new MemorySaver();

export async function runAgent({ sessionId = "default", message }: { sessionId?: string; message: string }) {
  const model = new ChatOpenAI({
    modelName: "gpt-4o",
    temperature: 0,
  });

  const agent = createReactAgent({
    llm: model,
    tools: [searchKnowledgeBase],
    checkpointSaver: checkpointer,
    messageModifier: `You are Slitch AI, a specialized technical engineering assistant.
You have access to a knowledge base containing technical manuals, system identification data, and frequency response analysis reports.
When asked a technical question, always search the knowledge base first.
Be precise, technical, and concise in your responses.`,
  });

  const response = await agent.invoke(
    {
      messages: [{ role: "user", content: message }],
    },
    {
      configurable: {
        thread_id: sessionId,
      },
    }
  );

  const lastMessage = response.messages[response.messages.length - 1];
  return { output: lastMessage.content };
}
